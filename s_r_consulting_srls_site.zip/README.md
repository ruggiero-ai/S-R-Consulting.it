# S&R Consulting srls — Sito web

Sito statico completo per la società di consulenza fiscale S&R Consulting srls.

## Istruzioni
1. Estrai lo zip.
2. Apri `index.html` nel browser.

## Pubblicazione su GitHub Pages
1. Crea una repository su GitHub.
2. Carica i file.
3. Vai su *Settings → Pages* e seleziona `main` e `/root`.
4. Il sito sarà pubblicato su `https://tuonome.github.io/nome-repo/`.

## Dati fittizi
- Email: info@srconsulting.it
- Telefono: +39 02 9876 5432
- Indirizzo: Via Esempio 12, Milano

## Licenza
MIT License 2025 © S&R Consulting srls